import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'dart:async';

class CovidPage extends StatefulWidget {
  // const CovidPage({Key? key}) : super(key: key);

  @override
  _CovidPageState createState() => _CovidPageState();
}

class _CovidPageState extends State<CovidPage> {
  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.all(50.0),
      child: FutureBuilder(
        builder: (context, AsyncSnapshot snapshot) {
          return ListView.builder(
            itemBuilder: (BuildContext context, int index) {
              return MyBox(snapshot.data[index]['province'],
                  snapshot.data[index]['total_case'], context);
            },
            itemCount: snapshot.data.length,
          );
        },
        future: getData(),
      ),
    );
  }
}

Widget MyBox(String province, int total_case, context) {
  var text_total_case = total_case.toString();
  var text_province = province;
  return Container(
    child: Column(
      children: [
        Card(
          child: ListTile(
            leading: FlutterLogo(),
            title: Text(
                'จังหวัด $text_province จำนวนผู้ติดเชื้อ $text_total_case คน'),
          ),
        ),
      ],
    ),
  );
}

Future getData() async {
  // https://covid19.ddc.moph.go.th/api/Cases/today-cases-by-provinces
  var url =
      Uri.https('covid19.ddc.moph.go.th', 'api/Cases/today-cases-by-provinces');
  var response = await http.get(url);
  var result = json.decode(response.body);
  return result;
}
